<?php

$vue = array(
	'ajoutEditTache' => "views/ajoutEditTache.php",
	'erreur' => "views/erreur.php",
	'formAddEditList' => "views/formAddEditList.php",
	'header' => "views/header.php",
	'login' => "views/login.php",
	'showList' => "views/showList.php",
	'showTask' => "views/showTask.php",
	'signup' => "views/signup.php"
);
 ?>
