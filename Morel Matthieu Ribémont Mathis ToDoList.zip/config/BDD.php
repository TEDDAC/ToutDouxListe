<?php
$user= 'root';
$pass='3.14159265359';
$dsn='mysql:host=localhost;dbname=toutdouxliste';
?>
