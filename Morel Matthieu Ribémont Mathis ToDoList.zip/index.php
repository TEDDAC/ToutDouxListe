<?php
require_once(__DIR__.'/config/Autoload.php');
require_once("config/config.php");
Autoload::charger();
$controller = new FrontController();
?>
